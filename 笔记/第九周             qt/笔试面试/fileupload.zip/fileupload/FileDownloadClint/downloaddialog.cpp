#include "downloaddialog.h"
#include "ui_downloaddialog.h"
#include <QDataStream>

DownloadDialog::DownloadDialog(QString name, QString filepath, QString ip, int port, QWidget *parent):
    m_name(name),
    m_filepath(filepath),
    QDialog(parent),
    ui(new Ui::DownloadDialog)
{
    ui->setupUi(this);
    m_socket = new QTcpSocket(this);
    m_socket->connectToHost(ip, port);
    connect(m_socket, SIGNAL(connected()), this, SLOT(connected()));
    connect(m_socket, SIGNAL(readyRead()), this, SLOT(readReady()));
    //如果下载的文件已经存在，删除
    m_file = new QFile(m_filepath+"/"+m_name);
    m_file->open(QIODevice::WriteOnly);
    ui->label_name->setText(name);
}

DownloadDialog::~DownloadDialog()
{
    delete ui;
    m_file->close();
    m_socket->close();
}

void DownloadDialog::readReady()
{
    /*
    数据头的格式
    第一字节：类型（上传，下载，获取文件列表）
    第二字节：上传或者下载文件大小的字节数
    第三字节----3+len：文件大小字符串
    后面所有：文件内容
    */
    if(!m_start)//在下载刚开始的时候获取数据头信息
    {
        m_start = true;
        char order;
        char len;
        char buf[20] = {0};
        m_socket->read(&order, 1);//数据类型
        m_socket->read(&len, 1);//获得数据大小的字节长度
        m_socket->read(buf, len);//读取数据大小
        QString ssize(buf);
        m_filesize = ssize.toLongLong();
        ui->progressBar->setMaximum(m_filesize);
    }
    QByteArray data = m_socket->readAll();
    int writesize = m_file->write(data);
    ui->progressBar->setValue(ui->progressBar->value()+writesize);
    m_downloadCount += writesize;
    //文件下载完毕通知服务器关闭连接
    if(m_downloadCount == m_filesize)
    {
        QByteArray data;
        data.append((char)FINISH);
        m_socket->write(data);
        m_socket->close();
        m_file->close();
    }
    
}

void DownloadDialog::connected()
{
    QByteArray data;
    data.append((char)DOWNLOAD);
    data.append(m_name.toLocal8Bit());
    m_socket->write(data);//发送下载请求
}
