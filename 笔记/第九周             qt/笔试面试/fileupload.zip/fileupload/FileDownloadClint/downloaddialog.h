#ifndef DOWNLOADDIALOG_H
#define DOWNLOADDIALOG_H

#include <QDialog>
#include <QTcpSocket>
#include <QFile>

#define DOWNLOAD 0
#define UPLOAD   1
#define FILES    2
#define FINISH   3

namespace Ui {
class DownloadDialog;
}

class DownloadDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit DownloadDialog(QString name, QString savepath, QString ip, int port, QWidget *parent = 0);
    ~DownloadDialog();
    
private:
    Ui::DownloadDialog *ui;
    
    QString m_name;
    QString m_filepath;
    QTcpSocket* m_socket;
    QFile* m_file;
    bool m_start = false;
    qint64 m_filesize;
    qint64 m_downloadCount = 0;
private slots:
    void readReady();
    void connected();
};

#endif // DOWNLOADDIALOG_H
