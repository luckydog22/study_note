﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>
#include "downloaddialog.h"
#include <QDir>
#include "uploaddialog.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //初始化
    init();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_listWidget_files_itemClicked(QListWidgetItem *item)
{
    ui->lineEdit_file->setText(item->text());
}

void MainWindow::on_pushButton_flush_clicked()
{
    ui->listWidget_files->clear();
    getFileList();   
}

void MainWindow::on_pushButton_connect_clicked()
{
    if(!m_socket)
    {
        return;
    }
    int port = ui->lineEdit_port->text().toInt();
    QString ip = ui->lineEdit_ip->text();
    m_socket->connectToHost(ip, port);
    getFileList();
}

void MainWindow::on_pushButton_download_clicked()
{
    DownloadDialog* dialog = new DownloadDialog(
                ui->lineEdit_file->text(), 
                m_basepath, 
                ui->lineEdit_ip->text(),
                ui->lineEdit_port->text().toInt(),
                this);
    dialog->show();
    connect(dialog, SIGNAL(rejected()), this, SLOT(on_pushButton_localflush_clicked()));
}

void MainWindow::connected()
{
    QMessageBox::information(this,"连接服务器成功","连接服务器成功");
    ui->pushButton_connect->setEnabled(false);
}

void MainWindow::disConnect()
{
    
}

void MainWindow::readReady()
{
    int size = -1;
    char buf[1024] = {0};
    while((size = m_socket->readLine(buf, sizeof(buf)))!=0)
    {
        QByteArray byteData(buf, size);
        QString data = QString::fromLocal8Bit(byteData);
        data.remove("\n");//服务器发送的数据每个文件名后面有\n
        ui->listWidget_files->addItem(data);
    }
}

void MainWindow::init()
{
    m_socket = new QTcpSocket(this);
    //连接成功信号，断开连接信号，读取数据信号
    connect(m_socket, SIGNAL(connected()), this, SLOT(connected()));
    connect(m_socket, SIGNAL(disconnected()), this, SLOT(disConnect()));
    connect(m_socket, SIGNAL(readyRead()), this, SLOT(readReady()));
    //获取路径中的文件名 显示到列表中
    getLocalFileList();
}

void MainWindow::getFileList()
{
    QByteArray data;
    data.append(FILES);
    m_socket->write(data.data(), data.size());
}

//获取路径中的文件名 显示到列表中
void MainWindow::getLocalFileList()
{
    QDir dir(m_basepath);
    //创建保存文件路径
    if(!dir.exists())
        dir.mkpath(m_basepath);
    //初始化文件列表
    QStringList fileList = dir.entryList();
    //注意是从2开始遍历
    for(int i = 2;i < fileList.size();i++)
    {
        //将内容显示到列表中
        ui->listWidget_localfiles->addItem(fileList.at(i));
    }
}
//void MainWindow::on_lineEdit_downloadpath_selectionChanged()
//{
//    QString basepath = QFileDialog::getExistingDirectory(this, "选择保存路径", "d:/");
//}

void MainWindow::on_lineEdit_upload_selectionChanged()
{
    m_uploadfile = QFileDialog::getOpenFileName(this, "选择上传的文件", m_basepath);
//    ui->lineEdit_upload->setText(m_uploadfile);
}

void MainWindow::on_pushButton_upload_clicked()
{
    UploadDialog* dialog = new UploadDialog(
                ui->lineEdit_upload->text(), 
                m_basepath,
                ui->lineEdit_ip->text(),
                ui->lineEdit_port->text().toInt(),
                this);
    dialog->show();
}

void MainWindow::on_pushButton_localflush_clicked()
{
    ui->listWidget_localfiles->clear();
    getLocalFileList();
}

void MainWindow::on_listWidget_localfiles_itemClicked(QListWidgetItem *item)
{
    ui->lineEdit_upload->setText(item->text());
}

void MainWindow::contextMenuEvent(QContextMenuEvent *event)
{
    //qDebug()<<event->pos();//窗口坐标
    //qDebug()<<QCursor::pos();//屏幕坐标
    //将鼠标的坐标转换到控件坐标内
    QPoint pos = ui->listWidget_localfiles->mapFromGlobal(QCursor::pos());
    //判断是否点中了某个控件
    QListWidgetItem* item = ui->listWidget_localfiles->itemAt(pos);
    if(item != NULL)
    {
        m_deleteItem = item;
        //删除pop菜单
        QMenu* popMenu = new QMenu(this);
        QAction* pdelAction = new QAction("删除",this);
        connect(pdelAction, SIGNAL(triggered()), this, SLOT(delFile()));
        popMenu->addAction(pdelAction);
        popMenu->exec(QCursor::pos());
       
    }
}

void MainWindow::delFile()
{
    QString delFilename = m_deleteItem->text();
    delete m_deleteItem;
    m_deleteItem = NULL;
    
    QFile file(m_basepath+delFilename);
    if(!file.remove())
        qDebug()<<"删除文件失败";
}
