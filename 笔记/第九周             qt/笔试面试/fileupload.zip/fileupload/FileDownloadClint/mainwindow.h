﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QListWidgetItem>

#define DOWNLOAD 0
#define UPLOAD   1
#define FILES    2

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();



private slots:
    void on_listWidget_files_itemClicked(QListWidgetItem *item);
    
    void on_pushButton_flush_clicked();
    
    void on_pushButton_connect_clicked();
    
    void on_pushButton_download_clicked();
    
    void connected();
    void disConnect();
    void readReady();
    //void on_lineEdit_downloadpath_selectionChanged();
    
    void on_lineEdit_upload_selectionChanged();
    
    void on_pushButton_upload_clicked();
    
    void on_pushButton_localflush_clicked();
    
    void on_listWidget_localfiles_itemClicked(QListWidgetItem *item);
    
    //鼠标右键
    void contextMenuEvent(QContextMenuEvent *event);
    void delFile();
    
private:
    Ui::MainWindow *ui;
    QTcpSocket* m_socket;
    QString m_basepath = "d:/jiahongdi/";
    QString m_uploadfile;
    
    QListWidgetItem* m_deleteItem;
    
    void init();
    void getFileList();
    void getLocalFileList();
};

#endif // MAINWINDOW_H
