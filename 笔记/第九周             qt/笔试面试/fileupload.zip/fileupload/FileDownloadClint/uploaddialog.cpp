#include "uploaddialog.h"
#include "ui_uploaddialog.h"
#include <QDebug>

UploadDialog::UploadDialog(QString name, QString basepath,  QString ip, int port, QWidget *parent) :
    m_name(name),
    m_basepath(basepath),
    QDialog(parent),
    ui(new Ui::UploadDialog)
{
    ui->setupUi(this);
    
    m_socket = new QTcpSocket(this);
    m_socket->connectToHost(ip, port);
    connect(m_socket, SIGNAL(connected()), this, SLOT(connected()));
    connect(m_socket, SIGNAL(readyRead()), this, SLOT(readReady()));
    
    ui->label_name->setText(m_name);
}

UploadDialog::~UploadDialog()
{
    delete ui;
}

void UploadDialog::readReady()
{
    char order;
    m_socket->read(&order, 1);
    if(order == FINISH)
    {
        delete this;
    }
}

void UploadDialog::connected()
{
    QFile file(m_basepath+m_name);
    if(!file.open(QIODevice::ReadOnly))
    {
        qDebug()<<"上传文件打开失败";
        return;
    }
    qint64 filesize = file.size();
    ui->progressBar->setMaximum(filesize);
    //数据头
    QByteArray head;
    head.append((char)UPLOAD);//数据类型为下载
    QString ssize = QString("%1").arg(filesize);
    head.append((char)ssize.size());//数据长度
    head.append(ssize);
    head.append((char)(m_name.toLocal8Bit().size()));//名字长度
    head.append(m_name.toLocal8Bit());
    m_socket->write(head);
    //文件流
    int count = 0;
    while(1)
    {
        char buf[1024] = {0};
        int size = file.read(buf, 1024);
        if(size == 0)
            break;
        m_socket->write(buf, size);
        count += size;
        ui->progressBar->setValue(count);
    }
    qDebug()<<count;
    m_socket->flush();
    file.close();
}
