#ifndef UPLOADDIALOG_H
#define UPLOADDIALOG_H

#include <QDialog>
#include <QTcpSocket>
#include <QFile>

#define DOWNLOAD 0
#define UPLOAD   1
#define FILES    2
#define FINISH   3

namespace Ui {
class UploadDialog;
}

class UploadDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit UploadDialog(QString name, QString basepath,  QString ip, int port, QWidget *parent = 0);
    ~UploadDialog();
    
private:
    Ui::UploadDialog *ui;
    
    QTcpSocket* m_socket;
    QString m_name;
    QString m_basepath;
private slots:
    void readReady();
    void connected();
};

#endif // UPLOADDIALOG_H
