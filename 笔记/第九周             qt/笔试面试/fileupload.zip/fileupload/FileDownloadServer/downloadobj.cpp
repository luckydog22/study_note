#include "downloadobj.h"
#include <QDir>
#include <QThread>

DownloadObj::DownloadObj(QTcpSocket *socket, QObject *parent):
    m_socket(socket),
    QObject(parent)
{
    m_basePath = "d:/shenwanlong/";
    m_socket->setParent(this);
    connect(m_socket, SIGNAL(readyRead()), this, SLOT(readReady()));
}

DownloadObj::~DownloadObj()
{
    m_socket->close();
}

void DownloadObj::readReady()
{
    if(m_start)
    {
        upload();
        return;
    }
    char order;
    m_socket->read(&order, 1);
    m_order = order;
    if(m_order == FILES)
    {
        files();
    }
    else if(m_order == DOWNLOAD)
    {
        download();   
    }
    else if(m_order == FINISH)
    {
        qDebug()<<"文件下载完毕";
        delete this;
    }
    else if(m_order == UPLOAD)
    {
        upload();
    }
}

void DownloadObj::files()
{
    QDir basePath(m_basePath);
    QStringList fileList = basePath.entryList();
    for(int i = 2;i < fileList.size();i++)
    {
        QString file = fileList.at(i)+"\n";
        m_socket->write(file.toLocal8Bit(), file.toLocal8Bit().size());
    }
}

void DownloadObj::download()
{
    QString filename = QString::fromLocal8Bit(m_socket->readAll());
    QFile file(m_basePath+"/"+filename);
    file.open(QIODevice::ReadOnly);
    qint64 filesize = file.size();
    //数据头
    QByteArray head;
    head.append((char)DOWNLOAD);//数据类型为下载
    QString ssize = QString("%1").arg(filesize);
    head.append((char)ssize.size());//数据长度
    head.append(ssize);
    m_socket->write(head);
    //文件流
    int count = 0;
    while(1)
    {
        char buf[1024] = {0};
        int size = file.read(buf, 1024);
        if(size == 0)
            break;
        m_socket->write(buf, size);
        count += size;
    }
    qDebug()<<count;
    m_socket->flush();
    file.close();
    //delete this;
}

void DownloadObj::upload()
{
    if(!m_start)
    {
        m_start = true;
        char len;
        char buf[20] = {0};
        m_socket->read(&len, 1);//获得数据大小的字节长度
        m_socket->read(buf, len);//读取数据大小
        QString ssize(buf);
        m_filesize = ssize.toLongLong();
        //读取文件名
        char nameSize;
        m_socket->read(&nameSize, 1);
        char namebuf[128] = {0};
        m_socket->read(namebuf, nameSize);
        m_downloadFile = new QFile(m_basePath+QString::fromLocal8Bit(QByteArray(namebuf)));
        if(!m_downloadFile->open(QIODevice::WriteOnly))
        {
            qDebug()<<"打开文件失败"<<m_downloadFile->fileName();
            return;
        }
        m_downloadCount = 0;
    }
    
    QByteArray data = m_socket->readAll();
    int writesize = m_downloadFile->write(data);
    m_downloadCount += writesize;
    qDebug()<<"write "<<writesize;
    //文件下载完毕通知服务器关闭连接
    if(m_downloadCount == m_filesize)
    {
        qDebug()<<"upload finish";
        QByteArray data;
        data.append((char)FINISH);
        m_socket->write(data);
        m_socket->flush();
        m_socket->close();
        m_downloadFile->close();
        delete this;
    }
}



