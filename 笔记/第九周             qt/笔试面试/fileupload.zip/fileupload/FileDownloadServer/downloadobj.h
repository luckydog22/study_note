#ifndef CLINTTHREAD_H
#define CLINTTHREAD_H

#include <QDebug>
#include <QTcpSocket>
#include <QFile>

#define DOWNLOAD 0
#define UPLOAD   1
#define FILES    2
#define FINISH   3

class DownloadObj : public QObject
{
    Q_OBJECT
public:
    DownloadObj(QTcpSocket* socket, QObject* parent = 0);
    ~DownloadObj();
    
private slots:
    void readReady();
private:
    QTcpSocket* m_socket;
    
    QString m_basePath;
    int m_order;
    
    bool m_start = false;
    qint64 m_filesize;
    qint64 m_downloadCount = 0;
    QFile* m_downloadFile;
    
    void files();
    void download();
    void upload();
};

#endif // CLINTTHREAD_H
