#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QHostInfo>
#include <QFileDialog>
#include <QDebug>
#include "downloadobj.h"

#define DOWNLOAD 0
#define UPLOAD   1
#define FILES    2
#define FINISH   3

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    init();    
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_addfile_clicked()
{
    QString filePath = QFileDialog::getOpenFileName(this,"选择添加到服务器的文件","d:/");
    QFile src(filePath);
    QFileInfo srcInfo(src);
    QString fileName = srcInfo.fileName();
    
    
    bool ok = src.copy(filePath, m_baseDir+"/"+fileName);
    qDebug()<<filePath;
    qDebug()<<fileName;
    qDebug()<< m_baseDir+"/"+fileName;
    if(!ok)
        qDebug()<<"添加文件失败";
    
    ui->listWidget_files->addItem(fileName);
}

void MainWindow::on_pushButton_start_clicked()
{
    m_port = ui->lineEdit_port->text().toInt();
    //初始化服务端
    m_server = new QTcpServer(this);
    m_server->listen(QHostAddress::Any, m_port);
    connect(m_server, SIGNAL(newConnection()), this, SLOT(onNewConnect()));
    ui->pushButton_start->setEnabled(false);
}

void MainWindow::on_pushButton_stop_clicked()
{
    m_server->close();
    ui->pushButton_start->setEnabled(true);
}

void MainWindow::onNewConnect()
{
    QTcpSocket* socket = m_server->nextPendingConnection();
    DownloadObj* obj = new DownloadObj(socket);
    connect(obj, SIGNAL(destroyed()), this, SLOT(flushFileList()));
}

void MainWindow::init()
{
    QDir dir(m_baseDir);
    //创建保存文件路径
    if(!dir.exists())
        dir.mkpath(m_baseDir);
    
    
    QHostInfo info = QHostInfo::fromName(QHostInfo::localHostName());
    QList<QHostAddress> addrs = info.addresses();
    m_localIP = addrs[0].toString();
    for(int i = 0;i < addrs.size();i++)
    {
        if(addrs[i].protocol() == QAbstractSocket::IPv4Protocol)
        {
            ui->comboBox_ip->addItem(addrs[i].toString());
        }
    }
    
    flushFileList();
}

void MainWindow::on_comboBox_ip_currentTextChanged(const QString &arg1)
{
    m_localIP = arg1;
}

void MainWindow::contextMenuEvent(QContextMenuEvent *event)
{
    //qDebug()<<event->pos();//窗口坐标
    //qDebug()<<QCursor::pos();//屏幕坐标
    //将鼠标的坐标转换到控件坐标内
    QPoint pos = ui->listWidget_files->mapFromGlobal(QCursor::pos());
    //判断是否点中了某个控件
    QListWidgetItem* item = ui->listWidget_files->itemAt(pos);
    if(item != NULL)
    {
        m_deleteItem = item;
        //删除pop菜单
        QMenu* popMenu = new QMenu(this);
        QAction* pdelAction = new QAction("删除",this);
        connect(pdelAction, SIGNAL(triggered()), this, SLOT(delFile()));
        popMenu->addAction(pdelAction);
        popMenu->exec(QCursor::pos());
       
    }
}

void MainWindow::delFile()
{
    QString delFilename = m_deleteItem->text();
    delete m_deleteItem;
    m_deleteItem = NULL;
    
    QFile file(m_baseDir+delFilename);
    if(!file.remove())
        qDebug()<<"删除文件失败";
}

void MainWindow::flushFileList()
{
    ui->listWidget_files->clear();
    QDir dir(m_baseDir);
    //初始化文件列表
    QStringList fileList = dir.entryList();
    for(int i = 2;i < fileList.size();i++)
    {
        ui->listWidget_files->addItem(fileList.at(i));
    }
}