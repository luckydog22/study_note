#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFile>
#include <QDir>
#include <QTcpServer>
#include <QTcpSocket>
#include <vector>
#include <QListWidgetItem>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    
private slots:
    void on_pushButton_addfile_clicked();
    
    void on_pushButton_start_clicked();
    
    void on_pushButton_stop_clicked();
    
    void onNewConnect();
    void on_comboBox_ip_currentTextChanged(const QString &arg1);
    void contextMenuEvent(QContextMenuEvent *event);
    void delFile();
    void flushFileList();
private:
    Ui::MainWindow *ui;
    QTcpServer* m_server;
    int m_port;
    QString m_localIP;
    QListWidgetItem* m_deleteItem;
    
    QString m_baseDir="d:/shenwanlong/"; //保存服务器文件的路径
    
    void init();
};

#endif // MAINWINDOW_H
