#include "groupdialog.h"
#include "ui_groupdialog.h"
#include <QHostAddress>
#include "mainwindow.h"

GroupDialog::GroupDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::GroupDialog)
{
    ui->setupUi(this);
    socket = new QUdpSocket(this);
    socket->bind(QHostAddress(MainWindow::localIp), port);
    
    connect(socket, SIGNAL(readyRead()), this, SLOT(readData()));
}

GroupDialog::~GroupDialog()
{
    delete ui;
}

void GroupDialog::on_pushButton_send_clicked()
{
    QString data = ui->textEdit->toPlainText();
    QByteArray senddata = data.toLocal8Bit();
    int length = socket->writeDatagram(
                senddata,
                QHostAddress::Broadcast,//指定向广播地址发送
                port          
                );
}

void GroupDialog::readData()
{
    while(socket->hasPendingDatagrams())//判断socket是否有数据报 可读
    {
        QByteArray data;
        data.resize(socket->pendingDatagramSize());
        QHostAddress addr;
        socket->readDatagram(data.data(), data.size(), &addr);
        
        ui->textBrowser->append(addr.toString()+" : "+QString::fromLocal8Bit(data));
    }
}
