#ifndef GROUPDIALOG_H
#define GROUPDIALOG_H

#include <QDialog>
#include <QUdpSocket>

namespace Ui {
class GroupDialog;
}

class GroupDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit GroupDialog(QWidget *parent = 0);
    ~GroupDialog();
    
private slots:
    void on_pushButton_send_clicked();
    
    void readData();
private:
    Ui::GroupDialog *ui;
    int port = 66667;
    
    QUdpSocket* socket;
};

#endif // GROUPDIALOG_H
