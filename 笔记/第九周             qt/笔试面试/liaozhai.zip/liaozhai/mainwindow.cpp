﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QHostAddress>
#include <QDebug>
#include <QHostInfo>
#include "groupdialog.h"

QString MainWindow::localIp;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    initServer();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::initServer()
{
    server = new QTcpServer(this);
    server->listen(QHostAddress::Any, port);
    connect(server, SIGNAL(newConnection()), this, SLOT(newConnect()));
    
    QHostInfo info = QHostInfo::fromName(QHostInfo::localHostName());
    QList<QHostAddress> addrs = info.addresses();
    localIp = addrs[0].toString();
    for(int i = 0;i < addrs.size();i++)
    {
        if(addrs[i].protocol() == QAbstractSocket::IPv4Protocol)
        {
            ui->comboBox->addItem(addrs[i].toString());
        }
    }
}

void MainWindow::newConnect()
{
    QTcpSocket* socket = server->nextPendingConnection();
    //私撩对话框先不显示，等待用户点击
    PrivateDialog* dialog = new PrivateDialog(socket, this);
    dialogs.push_back(dialog);
    //将用户ip添加到listwidget中   ip = socket->peerAddress().toString();
    ui->listWidget->addItem(dialog->toString());
}

void MainWindow::on_pushButton_connect_clicked()
{
    QTcpSocket* socket = new QTcpSocket;
    socket->connectToHost(QHostAddress(ui->lineEdit->text()), port);
    PrivateDialog* dialog = new PrivateDialog(socket, this, ui->lineEdit->text());
    dialog->show();
}

void MainWindow::on_pushButton_group_clicked()
{
    GroupDialog* dialog = new GroupDialog(this);
    dialog->show();
}

void MainWindow::on_listWidget_itemDoubleClicked(QListWidgetItem *item)
{
    for(vector<PrivateDialog*>::iterator iter = dialogs.begin();iter != dialogs.end();iter++)
    {
        if((*iter)->equalsIp(item->text()))
        {
            (*iter)->show();// 显示私撩对话框
            dialogs.erase(iter);//从等待对话框中删除
            break;
        }
    }
    delete item;
}

void MainWindow::on_comboBox_currentIndexChanged(const QString &arg1)
{
    localIp = arg1;
}
