#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpServer>
#include <QTcpSocket>
#include <vector>
#include <QListWidgetItem>
#include "privatedialog.h"

using namespace std;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    
    static QString localIp;
private:
    Ui::MainWindow *ui;
    
    QTcpServer* server;
    int port = 66666;
    
    vector<PrivateDialog*> dialogs;//保存还没有被用户点开的私撩对话框
    
    void initServer();
private slots:
    void newConnect();
    void on_pushButton_connect_clicked();
    void on_pushButton_group_clicked();
    void on_listWidget_itemDoubleClicked(QListWidgetItem *item);
    void on_comboBox_currentIndexChanged(const QString &arg1);
};

#endif // MAINWINDOW_H
