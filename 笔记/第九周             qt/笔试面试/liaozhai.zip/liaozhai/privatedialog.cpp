#include "privatedialog.h"
#include "ui_privatedialog.h"
#include <QHostAddress>
#include "mainwindow.h"

PrivateDialog::PrivateDialog(QTcpSocket* socket, QWidget *parent, QString peerIp) :
    QDialog(parent),
    ui(new Ui::PrivateDialog),
    socket(socket)
{
    ui->setupUi(this);
    socket->setParent(this);
    ip = socket->peerAddress().toString();
    if(peerIp != "")
    {
        ip = peerIp;
    }
    
    connect(socket, SIGNAL(connected()), this, SLOT(friendConnect()));
    connect(socket, SIGNAL(disconnected()), this, SLOT(friendDisconnect()));
    connect(socket, SIGNAL(readyRead()), this, SLOT(readFriendData()));
}

PrivateDialog::~PrivateDialog()
{
    delete ui;
}

void PrivateDialog::on_pushButton_send_clicked()
{
    QString textData = ui->textEdit->toPlainText();
    socket->write(textData.toLocal8Bit().data(), textData.toLocal8Bit().size());
    ui->textBrowser->append(MainWindow::localIp+" : "+textData);
}

void PrivateDialog::friendConnect()
{
    ui->textBrowser->append(ip+" ："+QString("连接成功"));
}

void PrivateDialog::friendDisconnect()
{
    ui->textBrowser->append(ip+" ："+QString("已经断开连接"));
}

void PrivateDialog::readFriendData()
{
    QByteArray data = socket->readAll();
    ui->textBrowser->append(ip+" : "+QString::fromLocal8Bit(data));
}
