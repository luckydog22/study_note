#ifndef PRIVATEDIALOG_H
#define PRIVATEDIALOG_H

#include <QDialog>
#include <QTcpSocket>

namespace Ui {
class PrivateDialog;
}

class PrivateDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit PrivateDialog(QTcpSocket* socket, QWidget *parent = 0, QString peerIp = "");
    ~PrivateDialog();
    
    inline QString toString(){return ip;}
    
    inline bool equalsIp(QString ip){return this->ip == ip;}
private slots:
    void on_pushButton_send_clicked();
    
    void friendConnect();
    void friendDisconnect();
    void readFriendData();
private:
    Ui::PrivateDialog *ui;
    QTcpSocket* socket;
    QString ip;
};

#endif // PRIVATEDIALOG_H
